Samples for quick testing. Includes UTF-8/ÅÄÖ content.
