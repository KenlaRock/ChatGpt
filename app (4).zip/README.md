# Data Viewer & Converter — v2.2 · Final

**Build:** 2025-09-12 00:00:00

**Status:** Final — *full‑feature release*

Den här versionen sammanför alla funktioner från tidigare milstolpar och lägger till mobilfixar och tabell‑virtualisering. Applikationen är en helt lokal/offline SPA som arbetar med JSON, XML, YAML, CSV, Markdown och HTML. Du kan importera data, visualisera den i olika vyer, redigera, konvertera mellan format och exportera – inklusive single‑file HTML och PDF (via utskrift). 

## Nytt i Final (2025‑09‑12)

* **Mobilfix & CSP:** En off‑canvas meny med ☰‑knapp gör sidopanelen åtkomlig på skärmar <900 px. Content‑Security‑Policy tillåter `blob:` så att web workers fungerar från `file://`‑URL:er. Om Workers blockeras faller parsern tillbaka till main‑thread. Om urklippet inte är tillgängligt används en prompt.
* **Worker‑fallback:** All parsing sker i Web Worker när det är möjligt. Om Worker inte kan skapas eller postMessage misslyckas, används en identisk parser i huvudtråden.
* **Tabell‑virtualisering:** Tabellvyn renderar nu upp till ~50 000 rader med en virtuell scrollbar. Bara synliga rader skapas i DOM vilket ger mycket bättre prestanda. Inline‑redigering fungerar fortfarande, och ändringar hamnar i undo/redo.
* **Undo/Redo & Snapshots integrerade:** Finalversionen inkluderar full historik (≥200 steg) och snapshots i IndexedDB. Du kan spara och ladda upp till 20 snapshots.
* **Mindmap pan/zoom:** Interaktiv mindmap med pan/zoom som presenterades i M4, nu i slutlig version.

## Övriga funktioner

* Import via drag‑and‑drop, filväljare eller klistra in (med fallback‑prompt).
* Visualiseringsvyer: **Raw**, **Träd**, **Outline**, **Tabell** (virtualiserad), **Mindmap** (pan/zoom). Alla vyer uppdateras från samma datakälla.
* **Sök/Filter:** Fritextsök med regex‑stöd, presets för tomma värden, dubbletter och valideringsfel.
* **Schema‑validering:** Minimal JSON Schema‑validering visar antal fel och kan blockera export tills Force export bekräftas.
* **Konvertering & Export:** Konvertera mellan JSON/XML/YAML/CSV/MD/HTML. Exportera single‑file HTML eller PDF via webbläsarens utskrift. Export blockeras om datasetet är extremt stort eller valideringsfel finns (Force export med dubbel bekräftelse krävs).
* **Performance‑vakt:** Räknar noder och visar varning när datasetet överstiger ~200 000 noder. Memory/latens‑vakt visar banner och blockerar export när rendering riskerar att frysa browsern.
* **Tillgänglighet:** Uppfyller WCAG 2.2 AA: starka fokusmarkeringar, ARIA‑roller, tangentbordsnavigering och aria‑live för status.

## Användning

1. Öppna `app.html` i din webbläsare (rekommenderad: Chrome) från en lokal `file://`‑URL.
2. Importera data genom att dra och släppa en fil, använda **Öppna** eller klistra in med **Klistra in**. Om urklipp inte är tillgängligt visas en prompt där du kan klistra in.
3. Välj vy i sidopanelen (Raw, Träd, Outline, Tabell, Mindmap). På mobil öppnar du panelen med ☰.
4. Sök eller filtrera; använd presets för tomma värden, dubbletter och valideringsfel.
5. Aktivera **Edit** för att redigera tabellceller. Använd **Undo**/Redo och snapshots för att reversera eller spara lägen.
6. Klistra in ett JSON Schema i fältet “Schema‑validering” och tryck **Validera** för att granska data.
7. Använd **Konvertera & Exportera** för att skapa nya filer. För PDF‑export används webbläsarens utskrift (ctrl+p).
8. Om prestandavarning eller valideringsfel visas: bocka i **Force export** och bekräfta dialogen för att fortsätta.

Se även `CHANGELOG.md` och `QA-rapport.md` för detaljerade förändringar och testresultat.